import React from "react";

const Dashboard = () => {
  return (
    <div className="p-4">
      <h1 className="text-xl font-bold">BPM Web App - Dashboard</h1>
      <p>Selamat datang! Silakan pilih menu.</p>
    </div>
  );
};

export default Dashboard;